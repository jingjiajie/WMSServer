CREATE VIEW TaxItemView AS
  SELECT
    `WMS_Template`.`TaxItem`.`ID`          AS `ID`,
    `WMS_Template`.`TaxItem`.`TaxID`       AS `TaxID`,
    `WMS_Template`.`TaxItem`.`StartAmount` AS `StartAmount`,
    `WMS_Template`.`TaxItem`.`EndAmount`   AS `EndAmount`,
    `WMS_Template`.`TaxItem`.`Type`        AS `Type`,
    `WMS_Template`.`TaxItem`.`TaxAmount`   AS `TaxAmount`,
    `WMS_Template`.`TaxItem`.`TaxRate`     AS `TaxRate`
  FROM `WMS_Template`.`TaxItem`;

