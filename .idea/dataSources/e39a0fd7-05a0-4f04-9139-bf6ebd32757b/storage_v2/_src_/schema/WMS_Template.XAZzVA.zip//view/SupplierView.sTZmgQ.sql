CREATE VIEW SupplierView AS
  SELECT
    `WMS_Template`.`Supplier`.`ID`                  AS `ID`,
    `WMS_Template`.`Supplier`.`WarehouseID`         AS `WarehouseID`,
    `WMS_Template`.`Supplier`.`No`                  AS `No`,
    `WMS_Template`.`Supplier`.`FullName`            AS `FullName`,
    `WMS_Template`.`Supplier`.`Name`                AS `Name`,
    `WMS_Template`.`Supplier`.`EnterpriseCode`      AS `EnterpriseCode`,
    `WMS_Template`.`Supplier`.`ContractNo`          AS `ContractNo`,
    `WMS_Template`.`Supplier`.`ContractStartTime`   AS `ContractStartTime`,
    `WMS_Template`.`Supplier`.`ContractEndTime`     AS `ContractEndTime`,
    `WMS_Template`.`Supplier`.`InvoiceDelayMonth`   AS `InvoiceDelayMonth`,
    `WMS_Template`.`Supplier`.`BalanceDelayMonth`   AS `BalanceDelayMonth`,
    `WMS_Template`.`Supplier`.`NetArea`             AS `NetArea`,
    `WMS_Template`.`Supplier`.`FixedStorageCost`    AS `FixedStorageCost`,
    `WMS_Template`.`Supplier`.`ContractStorageArea` AS `ContractStorageArea`,
    `WMS_Template`.`Supplier`.`TaxpayerNumber`      AS `TaxpayerNumber`,
    `WMS_Template`.`Supplier`.`Address`             AS `Address`,
    `WMS_Template`.`Supplier`.`Tel`                 AS `Tel`,
    `WMS_Template`.`Supplier`.`BankName`            AS `BankName`,
    `WMS_Template`.`Supplier`.`BankAccount`         AS `BankAccount`,
    `WMS_Template`.`Supplier`.`BankNo`              AS `BankNo`,
    `WMS_Template`.`Supplier`.`ZipCode`             AS `ZipCode`,
    `WMS_Template`.`Supplier`.`RecipientName`       AS `RecipientName`,
    `WMS_Template`.`Supplier`.`ContractState`       AS `ContractState`,
    `WMS_Template`.`Supplier`.`IsHistory`           AS `IsHistory`,
    `WMS_Template`.`Supplier`.`NewestSupplierID`    AS `NewestSupplierID`,
    `WMS_Template`.`Supplier`.`CreatePersonID`      AS `CreatePersonID`,
    `WMS_Template`.`Supplier`.`CreateTime`          AS `CreateTime`,
    `WMS_Template`.`Supplier`.`LastUpdatePersonID`  AS `LastUpdatePersonID`,
    `WMS_Template`.`Supplier`.`LastUpdateTime`      AS `LastUpdateTime`,
    `WMS_Template`.`Warehouse`.`Name`               AS `WarehouseName`,
    `CreatePerson`.`Name`                           AS `CreatePersonName`,
    `LastUpdatePerson`.`Name`                       AS `LastUpdatePersonName`
  FROM (((`WMS_Template`.`Supplier`
    JOIN `WMS_Template`.`Warehouse`
      ON ((`WMS_Template`.`Supplier`.`WarehouseID` = `WMS_Template`.`Warehouse`.`ID`))) JOIN
    `WMS_Template`.`Person` `CreatePerson` ON ((`CreatePerson`.`ID` = `WMS_Template`.`Supplier`.`CreatePersonID`))) JOIN
    `WMS_Template`.`Person` `LastUpdatePerson`
      ON ((`LastUpdatePerson`.`ID` = `WMS_Template`.`Supplier`.`LastUpdatePersonID`)));

