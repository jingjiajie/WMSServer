CREATE VIEW AccountTitleView AS
  SELECT
    `WMS_Template`.`AccountTitle`.`ID`        AS `ID`,
    `WMS_Template`.`AccountTitle`.`Name`      AS `Name`,
    `WMS_Template`.`AccountTitle`.`No`        AS `No`,
    `WMS_Template`.`AccountTitle`.`Type`      AS `Type`,
    `WMS_Template`.`AccountTitle`.`Direction` AS `Direction`,
    `WMS_Template`.`AccountTitle`.`Enabled`   AS `Enabled`
  FROM `WMS_Template`.`AccountTitle`;

