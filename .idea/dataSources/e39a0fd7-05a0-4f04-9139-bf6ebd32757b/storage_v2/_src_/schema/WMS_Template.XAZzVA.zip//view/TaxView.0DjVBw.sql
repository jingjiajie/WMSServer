CREATE VIEW TaxView AS
  SELECT
    `WMS_Template`.`Tax`.`ID`   AS `ID`,
    `WMS_Template`.`Tax`.`Name` AS `Name`,
    `WMS_Template`.`Tax`.`No`   AS `No`
  FROM `WMS_Template`.`Tax`;

