CREATE VIEW WarehouseView AS
  SELECT
    `WMS_Template`.`Warehouse`.`ID`      AS `ID`,
    `WMS_Template`.`Warehouse`.`Name`    AS `Name`,
    `WMS_Template`.`Warehouse`.`Address` AS `Address`,
    `WMS_Template`.`Warehouse`.`Tel`     AS `Tel`
  FROM `WMS_Template`.`Warehouse`;

