CREATE VIEW PersonView AS
  SELECT
    `WMS_Template`.`Person`.`ID`              AS `ID`,
    `WMS_Template`.`Person`.`Name`            AS `Name`,
    `WMS_Template`.`Person`.`Password`        AS `Password`,
    `WMS_Template`.`Person`.`Role`            AS `Role`,
    `WMS_Template`.`Person`.`AuthorityString` AS `AuthorityString`
  FROM `WMS_Template`.`Person`;

