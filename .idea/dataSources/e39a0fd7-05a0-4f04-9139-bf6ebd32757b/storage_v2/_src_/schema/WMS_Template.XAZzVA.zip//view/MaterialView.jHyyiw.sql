CREATE VIEW MaterialView AS
  SELECT
    `WMS_Template`.`Material`.`ID`          AS `ID`,
    `WMS_Template`.`Material`.`Name`        AS `Name`,
    `WMS_Template`.`Material`.`WarehouseID` AS `WarehouseID`,
    `WMS_Template`.`Material`.`No`          AS `No`,
    `WMS_Template`.`Warehouse`.`Name`       AS `WarehouseName`
  FROM (`WMS_Template`.`Material`
    JOIN `WMS_Template`.`Warehouse` ON ((`WMS_Template`.`Material`.`WarehouseID` = `WMS_Template`.`Warehouse`.`ID`)));

